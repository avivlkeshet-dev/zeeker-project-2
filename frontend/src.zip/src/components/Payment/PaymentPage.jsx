import './PaymentPage.css'

function PaymentPage() {
    return (
        <div className="container-fluid payment-page d-flex flex-column position-relative">
            <div className="d-flex text-white justify-content-between">
            <div className='cross m-3'>
        <img src="../src/assets/X.png" />
      </div>
      <div>
        <h2 className='m-4 carName'>ביצוע תשלום</h2>
      </div>
      <div className='back m-3'>
        <img src="../src/assets/Back.png" />
      </div>
        </div>
        <div className="payment-page__progress">
            <img src="../src/assets/3.png" alt="Step 3 of 3" />
        </div>
        <div className='payment-page__subtitle text-white text-center'>
            <h2 className='requestText'>מעקב אחרי בקשת המימון</h2>
        </div>
        <div className='payment-page__timeline-container'>
            <div className='timeline-vertical-line'></div>
            <div className='timeline-row'>
                <div className='timeline-item'>
                    <img src="../src/assets/ElipseEmpty.png" alt="" />
                </div>
                <div className='textbubble d-flex flex-column align-items-start'>
                    <h1 className='BubbleTitle text-white mt-3 me-3'>פניה לסוכן</h1>
                    <img className='smallLine mt-3 me-3' src="./src/assets/smallLine.png" alt="" />
                    <p className='BubbleText mt-3 me-3'>העברנו את הבקשה לנציג/ת המכירות. בקרוב נעדכן אותך לגבי התקדמות הטיפול</p>
                </div>
            </div>
            <div className='timeline-row'>
                <div className='timeline-item'>
                    <img src="../src/assets/ElipseEmpty.png" alt="" />
                </div>
                <div className='textbubble d-flex flex-column align-items-start'>
                    <h1 className='BubbleTitle text-white mt-3 me-3'>הגשת בקשה</h1>
                    <img className='smallLine mt-3 me-3' src="./src/assets/smallLine.png" alt="" />
                    <p className='BubbleText mt-3 me-3'>בקשתך התקבלה והיא בטיפול סוכנ/ת המכירות</p>
                </div>
            </div>
            <div className='timeline-row'>
                <div className='timeline-item'>
                    <img src="../src/assets/ElipseEmpty.png" alt="" />
                </div>
                <div className='textbubble d-flex flex-column align-items-start'>
                    <h1 className='BubbleTitle text-white mt-3 me-3'>החתמת מסמכים</h1>
                    <img className='smallLine mt-3 me-3' src="./src/assets/smallLine.png" alt="" />
                    <p className='BubbleText mt-3 me-3'>לאחר הורכת המסמך, נבקש להחתים אותו בבנק או אצל הגוף המממן. בבקשה לשים לב שכל הפרטים נכונים</p>
                    <button className='downloadButton mb-4'><img className='ms-2' src="./src/assets/Download.png" alt="" />מסמך להורדה</button>
                </div>
            </div>
            <div className='timeline-row'>
                <div className='timeline-item'>
                    <img src="../src/assets/ElipseFull.png" alt="" />
                </div>
                <div className='textbubble d-flex flex-column align-items-start'>
                    <h1 className='BubbleTitle text-white mt-3 me-3'>העלאת המסמך</h1>
                    <img className='smallLine mt-3 me-3' src="./src/assets/smallLine.png" alt="" />
                    <p className='BubbleText mt-3 me-3'>העברנו את הבקשה לנציג/ת המכירות. בקרוב נעדכן אותך לגבי התקדמות הטיפול</p>
                    <form className='payment-page__form' action="/upload-destination" method="POST" enctype="multipart/form-data">
                        <label htmlFor="file-upload" className='uploadLabel mb-4'><img className='ms-2' src="./src/assets/Upload.png" alt="" />מסמך אישור מימון</label>
                        <input type='file' id='file-upload'></input>
                    </form>
                </div>
            </div>
        </div>
        <div className='text-center'>
            <button className='finishButton'>סיום תהליך</button>
        </div>
        </div>
    )
}
export default PaymentPage;